// The main.cpp you can use for testing will replace this file soon.

#include "provided.h"

int main()
{
}
