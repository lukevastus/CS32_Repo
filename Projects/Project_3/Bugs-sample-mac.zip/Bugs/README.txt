To run Bugs:

1. Locate the folder Bugs, which should have in it files named
Bugs and Assets.  It's likely that the path to the folder will be
/Users/yourname/Bugs or /Users/yourname/Downloads/Bugs.

2. Open a Terminal window and type
	cd whateverThePathIs
where you should replace whateverThePathIs with the path to the Bugs
folder.

3. Confirm you're in the right folder by typing
	ls
which should show you the Assets folder and the Bugs executable.

4. Type
	./Bugs field.txt USCAnt.bug USCAnt.bug USCAnt.bug USCAnt.bug 
to play the game with the field in field.txt and four colonies, each of
the kind USCAnt from the example in the spec.  You can type q to quit the
game prematurely.
